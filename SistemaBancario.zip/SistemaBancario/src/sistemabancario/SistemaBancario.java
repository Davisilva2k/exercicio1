
package sistemabancario;


public class SistemaBancario {

 
    public static void main(String[] args) {
        Cliente c1 = new Cliente("Matheus", "123456789");
    }
    
}
